import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { ensureBootstrap } from "@/lib/bootstrap";
import { Providers } from "@/components/providers";
import DashboardShell from "./_components/DashboardShell";
import type { ReactNode } from "react";

export const dynamic = "force-dynamic";

export default async function DashboardLayout({
  children,
}: {
  children: ReactNode;
}) {
  await ensureBootstrap();
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.status !== "ACTIVE") redirect("/login?suspended=1");

  return (
    <Providers>
      <DashboardShell
        user={{
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          avatarUrl: user.avatarUrl,
        }}
      >
        {children}
      </DashboardShell>
    </Providers>
  );
}
