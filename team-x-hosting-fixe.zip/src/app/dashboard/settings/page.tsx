"use client";
import { useEffect, useState } from "react";
import { Button, Card, Input, Label, useToast } from "@/components/ui";

export default function SettingsPage() {
  const [me, setMe] = useState<{ name: string; email: string } | null>(null);
  const [newPass, setNewPass] = useState("");
  const [oldPass, setOldPass] = useState("");
  const toast = useToast();

  useEffect(() => {
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => d.user && setMe({ name: d.user.name, email: d.user.email }));
  }, []);

  async function changePass() {
    const r = await fetch("/api/account/password", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ oldPassword: oldPass, newPassword: newPass }),
    });
    const d = await r.json();
    if (!r.ok) return toast.show(d.error || "Failed", "error");
    toast.show("Password updated", "success");
    setOldPass("");
    setNewPass("");
  }

  return (
    <div className="space-y-6 max-w-2xl">
      <h1 className="text-2xl font-bold">Account settings</h1>
      {me && (
        <Card>
          <h3 className="font-semibold mb-4">Profile</h3>
          <div className="space-y-4">
            <div>
              <Label>Name</Label>
              <Input value={me.name} disabled />
            </div>
            <div>
              <Label>Email</Label>
              <Input value={me.email} disabled />
            </div>
          </div>
        </Card>
      )}
      <Card>
        <h3 className="font-semibold mb-4">Change password</h3>
        <div className="space-y-4">
          <div>
            <Label>Current password</Label>
            <Input
              type="password"
              value={oldPass}
              onChange={(e) => setOldPass(e.target.value)}
            />
          </div>
          <div>
            <Label>New password</Label>
            <Input
              type="password"
              value={newPass}
              onChange={(e) => setNewPass(e.target.value)}
            />
            <p className="text-xs text-[color:var(--muted)] mt-1">
              At least 8 characters.
            </p>
          </div>
          <Button onClick={changePass} disabled={oldPass.length < 1 || newPass.length < 8}>
            Update password
          </Button>
        </div>
      </Card>
      {toast.element}
    </div>
  );
}
