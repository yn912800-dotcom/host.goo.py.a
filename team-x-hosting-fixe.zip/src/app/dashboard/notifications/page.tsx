"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Bell, Check } from "lucide-react";
import { Button, Card, EmptyState } from "@/components/ui";
import { timeAgo } from "@/lib/utils";

type Notif = {
  id: string;
  title: string;
  message: string;
  type: string;
  read: boolean;
  link: string | null;
  createdAt: string;
};

export default function NotificationsPage() {
  const [list, setList] = useState<Notif[] | null>(null);

  async function load() {
    const r = await fetch("/api/notifications");
    const d = await r.json();
    setList(d.notifications ?? []);
  }
  useEffect(() => {
    load();
  }, []);

  async function markAll() {
    await fetch("/api/notifications?id=all", { method: "POST" });
    load();
  }
  async function markOne(id: string) {
    await fetch(`/api/notifications?id=${id}`, { method: "POST" });
    load();
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Notifications</h1>
        <Button variant="secondary" size="sm" onClick={markAll}>
          <Check size={14} /> Mark all read
        </Button>
      </div>
      {!list ? (
        <div className="skeleton h-32" />
      ) : list.length === 0 ? (
        <Card>
          <EmptyState icon={<Bell size={20} />} title="No notifications" />
        </Card>
      ) : (
        <Card padding="p-0">
          <ul className="divide-y divide-[color:var(--border)]">
            {list.map((n) => (
              <li
                key={n.id}
                className={`px-5 py-4 flex items-start justify-between gap-4 ${
                  n.read ? "" : "bg-indigo-500/5"
                }`}
              >
                <div className="min-w-0">
                  <div className="font-medium">{n.title}</div>
                  <div className="text-sm text-[color:var(--muted)] mt-0.5">
                    {n.message}
                  </div>
                  {n.link && (
                    <Link
                      href={n.link}
                      className="text-xs text-indigo-400 hover:underline mt-1 inline-block"
                    >
                      Open →
                    </Link>
                  )}
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-xs text-[color:var(--muted)]">
                    {timeAgo(n.createdAt)}
                  </span>
                  {!n.read && (
                    <button
                      className="btn btn-ghost btn-sm"
                      onClick={() => markOne(n.id)}
                    >
                      <Check size={12} />
                    </button>
                  )}
                </div>
              </li>
            ))}
          </ul>
        </Card>
      )}
    </div>
  );
}
