"use client";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Upload,
  FileArchive,
  Code2,
  Settings as SettingsIcon,
  CheckCircle2,
  Rocket,
  AlertCircle,
} from "lucide-react";
import {
  Button,
  Card,
  Input,
  Label,
  Select,
  Textarea,
} from "@/components/ui";
import { formatBytes } from "@/lib/utils";
import { BOT_TEMPLATES, type BotTemplate, type TemplateEnv } from "@/lib/bot-templates";
import { Bot, Send, MessageCircle } from "lucide-react";

type Runtime = {
  id: number;
  type: string;
  version: string;
  displayName: string;
  installCommand: string | null;
  defaultStartCommand: string | null;
};

type Detected = {
  runtime: string;
  version?: string;
  entryPoint?: string;
  installCommand?: string;
  startCommand?: string;
  dependencies?: string[];
  confidence: number;
  notes: string[];
};

type UploadFile = {
  path: string;
  isDirectory?: boolean;
  content?: string;
  binaryContent?: string;
  isBinary?: boolean;
  sizeBytes?: number;
  mimeType?: string;
};

export default function NewServerWizard() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [runtimes, setRuntimes] = useState<Runtime[]>([]);
  const [selectedRuntime, setSelectedRuntime] = useState<string>("");
  const [runtimeVersion, setRuntimeVersion] = useState<string>("");
  const [files, setFiles] = useState<UploadFile[]>([]);
  const [detected, setDetected] = useState<Detected | null>(null);
  const [startCommand, setStartCommand] = useState("");
  const [installCommand, setInstallCommand] = useState("");
  const [entryPoint, setEntryPoint] = useState("");
  const [uploading, setUploading] = useState(false);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [template, setTemplate] = useState<BotTemplate | null>(null);
  const [envFields, setEnvFields] = useState<TemplateEnv[]>([]);
  const [envValues, setEnvValues] = useState<Record<string, string>>({});

  function pickTemplate(t: BotTemplate) {
    setError(null);
    setTemplate(t);
    if (!name.trim()) setName(t.id);
    setFiles(
      t.files.map((f) => ({
        path: f.path,
        content: f.content,
        sizeBytes: new TextEncoder().encode(f.content).length,
        isBinary: false,
      }))
    );
    setEnvFields(t.env);
    setEnvValues({});
    setDetected({
      runtime: t.runtime,
      entryPoint: t.entryPoint,
      installCommand: t.installCommand,
      startCommand: t.startCommand,
      confidence: 1,
      notes: [`Template: ${t.title}`, ...(t.notes ? [t.notes] : [])],
    });
    setStep(3);
  }

  function versionFor(type: string, preferred?: string) {
    const list = runtimes.filter((r) => r.type === type);
    return (list.find((r) => r.version === preferred) ?? list[0])?.version ?? "";
  }

  useEffect(() => {
    fetch("/api/runtimes")
      .then((r) => r.json())
      .then((d) => setRuntimes(d.runtimes ?? []));
  }, []);

  const runtimeFamilies = Array.from(
    new Map(runtimes.map((r) => [r.type, r])).values()
  );
  const versionsForSelected = runtimes.filter((r) => r.type === selectedRuntime);

  async function onFiles(fileList: FileList) {
    setError(null);
    setUploading(true);
    setUploadProgress(0);
    try {
      // If single zip, use detection endpoint
      const items = Array.from(fileList);
      if (items.length === 1 && items[0].name.toLowerCase().endsWith(".zip")) {
        const fd = new FormData();
        fd.append("file", items[0]);
        setUploadProgress(30);
        const res = await fetch("/api/detect", { method: "POST", body: fd });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Failed to analyze ZIP");
        setDetected(data.detected);
        setUploadProgress(60);

        // Also keep the file for later upload at create-time? Simpler: just read the ZIP client-side as base64 and store entries by re-extracting server-side.
        // For simplicity we send the raw file content array to the create API.
        // Re-read the file & build file entries from the detection response + actual entries via a second server call that returns the entries.
        const extractRes = await extractClientZip(items[0]);
        setFiles(extractRes);
        setUploadProgress(100);
      } else {
        // Multiple files: read each
        const toSet: UploadFile[] = [];
        for (const f of items) {
          const rel = (f as File & { webkitRelativePath?: string }).webkitRelativePath || f.name;
          const buf = new Uint8Array(await f.arrayBuffer());
          const isText = looksText(buf);
          toSet.push({
            path: rel,
            sizeBytes: f.size,
            mimeType: f.type,
            isBinary: !isText,
            content: isText ? new TextDecoder().decode(buf) : undefined,
            binaryContent: isText ? undefined : btoa(String.fromCharCode(...buf)),
          });
        }
        setFiles(toSet);
        // Detect from file list
        const detectRes = await fetch("/api/detect", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            files: toSet.map((f) => ({ path: f.path, content: f.content })),
          }),
        });
        const detectData = await detectRes.json();
        if (!detectRes.ok) throw new Error(detectData.error || "Detection failed");
        setDetected(detectData.detected);
        setUploadProgress(100);
      }
      // Prefill
      // move to detection step
      setStep(3);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setUploading(false);
    }
  }

  useEffect(() => {
    if (!detected) return;
    setSelectedRuntime(detected.runtime);
    setRuntimeVersion(versionFor(detected.runtime, detected.version));
    setStartCommand(detected.startCommand ?? "");
    setInstallCommand(detected.installCommand ?? "");
    setEntryPoint(detected.entryPoint ?? "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [detected, runtimes]);

  async function createServer() {
    setError(null);
    setCreating(true);
    try {
      // Validate runtime version against known
      const match = runtimes.find(
        (r) => r.type === selectedRuntime && (!runtimeVersion || r.version === runtimeVersion)
      );
      if (!match)
        throw new Error("Please select a valid runtime version");
      const missing = envFields.filter((f) => f.required && !envValues[f.key]?.trim());
      if (missing.length)
        throw new Error(`Please fill: ${missing.map((m) => m.label).join(", ")}`);
      const env = envFields
        .filter((f) => envValues[f.key]?.trim())
        .map((f) => ({ key: f.key, value: envValues[f.key].trim(), isSecret: f.secret }));

      const res = await fetch("/api/servers", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          name,
          description,
          runtime: selectedRuntime,
          runtimeVersion: match.version,
          startCommand: startCommand || match.defaultStartCommand,
          installCommand: installCommand || match.installCommand,
          entryPoint,
          files,
          env,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to create project");
      // Trigger initial deployment
      await fetch(`/api/servers/${data.server.id}/action`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "start" }),
      });
      router.push(`/dashboard/servers/${data.server.id}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setCreating(false);
    }
  }

  const totalSize = files.reduce((a, b) => a + (b.sizeBytes || 0), 0);

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold">New project</h1>
        <p className="text-sm text-[color:var(--muted)] mt-1">
          Create and deploy a new project in a few steps.
        </p>
      </div>

      <Stepper step={step} />

      {error && (
        <div className="card p-4 border-red-500/40 text-red-400 text-sm flex items-start gap-2">
          <AlertCircle size={16} className="mt-0.5" />
          <div>{error}</div>
        </div>
      )}

      {/* Step 1: Project */}
      {step === 1 && (
        <Card>
          <h2 className="font-semibold mb-4">Project details</h2>
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Project name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="my-cool-bot"
                maxLength={120}
              />
            </div>
            <div>
              <Label htmlFor="desc">Description (optional)</Label>
              <Textarea
                id="desc"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="What does your project do?"
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button disabled={!name.trim()} onClick={() => setStep(2)}>
                Next
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* Step 2: Upload */}
      {step === 2 && (
        <Card>
          <h2 className="font-semibold mb-1 flex items-center gap-2">
            <Bot size={16} className="text-indigo-300" /> Start from a bot template
          </h2>
          <p className="text-xs text-[color:var(--muted)] mb-3">
            Real, ready-to-run Telegram & WhatsApp bots in Python, Node.js and PHP.
          </p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2 mb-6">
            {BOT_TEMPLATES.filter((t) => runtimes.some((r) => r.type === t.runtime)).map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => pickTemplate(t)}
                className={`card-2 p-3 text-start hover:border-indigo-500/60 transition ${
                  template?.id === t.id ? "border-indigo-500/60" : ""
                }`}
              >
                <div className="flex items-center gap-2 font-medium text-sm">
                  {t.platform === "telegram" ? (
                    <Send size={14} className="text-sky-400" />
                  ) : (
                    <MessageCircle size={14} className="text-emerald-400" />
                  )}
                  {t.title}
                </div>
                <div className="text-xs text-[color:var(--muted)] mt-1 leading-relaxed">
                  {t.description}
                </div>
              </button>
            ))}
          </div>
          <h2 className="font-semibold mb-4">…or upload your own project</h2>
          <div className="space-y-4">
            <div
              className="border-2 border-dashed border-[color:var(--border)] rounded-xl p-8 text-center hover:border-indigo-500/50 transition cursor-pointer"
              onClick={() => fileInputRef.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                if (e.dataTransfer.files.length) onFiles(e.dataTransfer.files);
              }}
            >
              <Upload className="mx-auto text-[color:var(--muted)]" size={28} />
              <div className="mt-3 font-medium">
                Drop a <span className="text-indigo-300">.zip</span> or files here
              </div>
              <div className="text-xs text-[color:var(--muted)] mt-1">
                Up to 50 MB • We auto-detect your runtime
              </div>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                className="hidden"
                onChange={(e) => e.target.files && onFiles(e.target.files)}
              />
            </div>
            {uploading && (
              <div>
                <div className="h-2 rounded-full bg-[color:var(--card-2)] overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-indigo-500 to-violet-500 transition-all"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
                <div className="text-xs text-[color:var(--muted)] mt-2">
                  Analyzing project... {uploadProgress}%
                </div>
              </div>
            )}
            {files.length > 0 && !uploading && (
              <div className="card-2 p-3 text-sm flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileArchive size={16} className="text-indigo-300" />
                  <span>
                    {files.length} files • {formatBytes(totalSize)}
                  </span>
                </div>
              </div>
            )}
            <div className="flex justify-between gap-2">
              <Button variant="secondary" onClick={() => setStep(1)}>
                Back
              </Button>
              <div className="flex gap-2">
                <Button variant="secondary" onClick={() => setStep(3)}>
                  Skip upload
                </Button>
                <Button
                  disabled={files.length === 0}
                  onClick={() => setStep(3)}
                >
                  Next
                </Button>
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Step 3: Runtime */}
      {step === 3 && (
        <Card>
          <h2 className="font-semibold mb-4">Runtime & configuration</h2>
          {detected && (
            <div className="card-2 p-3 text-sm mb-4">
              <div className="flex items-center gap-2 text-emerald-300 font-medium">
                <CheckCircle2 size={14} /> Auto-detected:{" "}
                <span className="font-mono">{detected.runtime}</span>
                <span className="text-[color:var(--muted)] font-normal">
                  (confidence {(detected.confidence * 100).toFixed(0)}%)
                </span>
              </div>
              {detected.notes && (
                <ul className="text-xs text-[color:var(--muted)] mt-1 list-disc list-inside">
                  {detected.notes.map((n, i) => (
                    <li key={i}>{n}</li>
                  ))}
                </ul>
              )}
            </div>
          )}
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <Label>Runtime</Label>
              <Select
                value={selectedRuntime}
                onChange={(e) => setSelectedRuntime(e.target.value)}
              >
                <option value="">Select...</option>
                {runtimeFamilies.map((r) => (
                  <option key={r.type} value={r.type}>
                    {r.type}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Label>Version</Label>
              <Select
                value={runtimeVersion}
                onChange={(e) => setRuntimeVersion(e.target.value)}
                disabled={!selectedRuntime}
              >
                <option value="">Select...</option>
                {versionsForSelected.map((v) => (
                  <option key={v.id} value={v.version}>
                    {v.displayName}
                  </option>
                ))}
              </Select>
            </div>
            <div className="sm:col-span-2">
              <Label>Entry point (optional)</Label>
              <Input value={entryPoint} onChange={(e) => setEntryPoint(e.target.value)} placeholder="main.py" />
            </div>
            <div className="sm:col-span-2">
              <Label>Install command (optional)</Label>
              <Input
                value={installCommand}
                onChange={(e) => setInstallCommand(e.target.value)}
                placeholder="pip install -r requirements.txt"
              />
            </div>
            <div className="sm:col-span-2">
              <Label>Start command</Label>
              <Input
                value={startCommand}
                onChange={(e) => setStartCommand(e.target.value)}
                placeholder="python main.py"
              />
              <p className="text-xs text-[color:var(--muted)] mt-1">
                Runs without a shell. Allowed: python, node, npm, npx, php, composer. Use $PORT for the assigned port.
              </p>
            </div>
          </div>
          {envFields.length > 0 && (
            <div className="mt-6 space-y-3">
              <h3 className="font-semibold text-sm">Bot configuration</h3>
              {envFields.map((f) => (
                <div key={f.key}>
                  <Label>
                    {f.label} <span className="font-mono text-xs text-[color:var(--muted)]">({f.key})</span>
                    {f.required && <span className="text-red-400"> *</span>}
                  </Label>
                  <Input
                    type={f.secret ? "password" : "text"}
                    autoComplete="off"
                    placeholder={f.placeholder}
                    value={envValues[f.key] ?? ""}
                    onChange={(e) => setEnvValues((p) => ({ ...p, [f.key]: e.target.value }))}
                  />
                  <p className="text-xs text-[color:var(--muted)] mt-1">{f.help}</p>
                </div>
              ))}
              <p className="text-xs text-[color:var(--muted)]">
                Stored as environment variables (secrets are masked and redacted from logs). You can change them later in the Environment tab.
              </p>
            </div>
          )}
          <div className="flex justify-between gap-2 mt-6">
            <Button variant="secondary" onClick={() => setStep(2)}>
              Back
            </Button>
            <Button
              disabled={!selectedRuntime || !runtimeVersion}
              onClick={() => setStep(4)}
            >
              Next
            </Button>
          </div>
        </Card>
      )}

      {/* Step 4: Review */}
      {step === 4 && (
        <Card>
          <h2 className="font-semibold mb-4">Review & deploy</h2>
          <dl className="divide-y divide-[color:var(--border)]">
            <Row label="Name" value={name} />
            <Row label="Runtime" value={`${selectedRuntime} ${runtimeVersion}`} />
            <Row label="Entry point" value={entryPoint || "—"} />
            <Row label="Install" value={installCommand || "—"} />
            <Row label="Start" value={startCommand || "—"} />
            <Row label="Files" value={`${files.length} entries, ${formatBytes(totalSize)}`} />
          </dl>
          <div className="flex justify-between gap-2 mt-6">
            <Button variant="secondary" onClick={() => setStep(3)}>
              Back
            </Button>
            <Button loading={creating} onClick={createServer}>
              <Rocket size={14} /> Create & deploy
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="py-2.5 flex justify-between gap-4 text-sm">
      <dt className="text-[color:var(--muted)]">{label}</dt>
      <dd className="font-mono text-right truncate max-w-[60%]">{value}</dd>
    </div>
  );
}

function Stepper({ step }: { step: number }) {
  const steps = [
    { n: 1, label: "Details", icon: SettingsIcon },
    { n: 2, label: "Upload", icon: Upload },
    { n: 3, label: "Runtime", icon: Code2 },
    { n: 4, label: "Review", icon: Rocket },
  ];
  return (
    <div className="flex items-center gap-2 overflow-x-auto">
      {steps.map((s, i) => (
        <div key={s.n} className="flex items-center gap-2">
          <div
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm border ${
              step === s.n
                ? "bg-indigo-500/10 text-indigo-300 border-indigo-500/40"
                : step > s.n
                ? "bg-emerald-500/10 text-emerald-300 border-emerald-500/40"
                : "border-[color:var(--border)] text-[color:var(--muted)]"
            }`}
          >
            <s.icon size={14} />
            {s.label}
          </div>
          {i < steps.length - 1 && (
            <div className="w-6 h-px bg-[color:var(--border)]" />
          )}
        </div>
      ))}
    </div>
  );
}

function looksText(buf: Uint8Array): boolean {
  const sample = buf.slice(0, Math.min(1024, buf.length));
  let nonText = 0;
  for (const b of sample) {
    if (b === 0) return false;
    if (b < 7 || (b > 14 && b < 32)) nonText++;
  }
  return !(sample.length > 0 && nonText / sample.length > 0.3);
}

async function extractClientZip(file: File): Promise<UploadFile[]> {
  // Use the server to extract (POST /api/detect returned entries? no). Simpler: call a new endpoint.
  const fd = new FormData();
  fd.append("file", file);
  const res = await fetch("/api/extract-zip", { method: "POST", body: fd });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Failed to extract ZIP");
  return data.files as UploadFile[];
}
