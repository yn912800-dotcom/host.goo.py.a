"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Server as ServerIcon, Plus, Search } from "lucide-react";
import { Card, EmptyState, Input, Skeleton, StatusBadge } from "@/components/ui";
import { timeAgo } from "@/lib/utils";

type Server = {
  id: string;
  name: string;
  status: string;
  runtime: string;
  runtimeVersion: string;
  updatedAt: string;
  createdAt: string;
};

export default function ServersPage() {
  const [servers, setServers] = useState<Server[] | null>(null);
  const [q, setQ] = useState("");

  useEffect(() => {
    fetch("/api/servers")
      .then((r) => r.json())
      .then((d) => setServers(d.servers ?? []));
  }, []);

  const filtered = (servers ?? []).filter((s) =>
    q ? s.name.toLowerCase().includes(q.toLowerCase()) : true
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">My projects</h1>
          <p className="text-sm text-[color:var(--muted)] mt-1">
            Manage and deploy your projects.
          </p>
        </div>
        <Link href="/dashboard/servers/new" className="btn btn-primary">
          <Plus size={14} /> New project
        </Link>
      </div>

      <div className="relative max-w-xs">
        <Search
          size={14}
          className="absolute left-3 top-1/2 -translate-y-1/2 text-[color:var(--muted)]"
        />
        <Input
          placeholder="Search projects..."
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="pl-9"
        />
      </div>

      {!servers ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <EmptyState
            icon={<ServerIcon size={22} />}
            title={q ? "No matches" : "No projects yet"}
            description={q ? "Try a different query" : "Create your first project to deploy code in seconds."}
            action={
              <Link href="/dashboard/servers/new" className="btn btn-primary">
                <Plus size={14} /> New project
              </Link>
            }
          />
        </Card>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((s) => (
            <Link
              key={s.id}
              href={`/dashboard/servers/${s.id}`}
              className="card p-5 hover:border-indigo-500/50 transition group"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <h3 className="font-semibold truncate group-hover:text-indigo-300">
                    {s.name}
                  </h3>
                  <div className="text-xs text-[color:var(--muted)] mt-1">
                    {s.runtime} {s.runtimeVersion}
                  </div>
                </div>
                <StatusBadge status={s.status} />
              </div>
              <div className="text-xs text-[color:var(--muted)] mt-4">
                Updated {timeAgo(s.updatedAt)}
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
