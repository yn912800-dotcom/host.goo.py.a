"use client";
import { use, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Play,
  Square,
  RotateCw,
  Trash2,
  Terminal,
  FolderOpen,
  LineChart as LineChartIcon,
  Settings as SettingsIcon,
  Globe,
  Database,
  KeySquare,
  Rocket,
  Zap,
} from "lucide-react";
import { Button, Card, StatusBadge, useToast } from "@/components/ui";
import { formatUptime, timeAgo } from "@/lib/utils";
import FilesTab from "./_tabs/FilesTab";
import ConsoleTab from "./_tabs/ConsoleTab";
import MetricsTab from "./_tabs/MetricsTab";
import EnvTab from "./_tabs/EnvTab";
import DomainsTab from "./_tabs/DomainsTab";
import BackupsTab from "./_tabs/BackupsTab";
import SettingsTab from "./_tabs/SettingsTab";

type Server = {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  runtime: string;
  runtimeVersion: string;
  status: string;
  port: number | null;
  containerId: string | null;
  startCommand: string | null;
  installCommand: string | null;
  entryPoint: string | null;
  autoRestart: boolean;
  restartCount: number;
  cpuMillis: number;
  ramMb: number;
  storageMb: number;
  lastDeployedAt: string | null;
  lastStartedAt: string | null;
  createdAt: string;
  updatedAt: string;
};

type Tab = "console" | "files" | "metrics" | "env" | "domains" | "backups" | "settings";

export default function ServerDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const router = useRouter();
  const [srv, setSrv] = useState<Server | null>(null);
  const [tab, setTab] = useState<Tab>("console");
  const [acting, setActing] = useState<string | null>(null);
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  const toast = useToast();

  async function load() {
    const r = await fetch(`/api/servers/${id}`);
    const d = await r.json();
    if (d.server) setSrv(d.server);
  }

  useEffect(() => {
    load();
    const t = setInterval(load, 5000);
    return () => clearInterval(t);
  }, [id]); // eslint-disable-line

  async function action(a: "start" | "stop" | "restart" | "redeploy" | "kill") {
    setActing(a);
    try {
      const r = await fetch(`/api/servers/${id}/action`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: a }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || "Action failed");
      toast.show(`${a} initiated`, "success");
      load();
    } catch (e) {
      toast.show(e instanceof Error ? e.message : "Failed", "error");
    } finally {
      setActing(null);
    }
  }

  async function deleteServer() {
    if (!confirm("Delete this project? This cannot be undone.")) return;
    const r = await fetch(`/api/servers/${id}`, { method: "DELETE" });
    const d = await r.json();
    if (!r.ok) return toast.show(d.error || "Failed", "error");
    router.push("/dashboard/servers");
  }

  if (!srv) {
    return <div className="skeleton h-16" />;
  }

  const canStart = ["STOPPED", "CREATED", "ERROR", "CRASHED"].includes(srv.status);
  const canStop = ["RUNNING", "STARTING"].includes(srv.status);
  const busy = ["INSTALLING", "BUILDING", "STARTING", "STOPPING"].includes(srv.status);

  const tabs: { key: Tab; label: string; icon: React.ReactNode }[] = [
    { key: "console", label: "Console", icon: <Terminal size={14} /> },
    { key: "files", label: "Files", icon: <FolderOpen size={14} /> },
    { key: "metrics", label: "Metrics", icon: <LineChartIcon size={14} /> },
    { key: "env", label: "Environment", icon: <KeySquare size={14} /> },
    { key: "domains", label: "Domains", icon: <Globe size={14} /> },
    { key: "backups", label: "Backups", icon: <Database size={14} /> },
    { key: "settings", label: "Settings", icon: <SettingsIcon size={14} /> },
  ];

  return (
    <div className="space-y-5">
      {/* Header */}
      <Card>
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-3 flex-wrap">
              <h1 className="text-xl font-bold truncate">{srv.name}</h1>
              <StatusBadge status={srv.status} />
            </div>
            <div className="text-xs text-[color:var(--muted)] mt-1 space-x-3">
              <span>{srv.runtime} {srv.runtimeVersion}</span>
              {srv.port && <span>· port {srv.port}</span>}
              {srv.containerId?.startsWith("pid-") && (
                <span>· PID <span className="font-mono">{srv.containerId.slice(4)}</span></span>
              )}
              {srv.status === "RUNNING" && srv.lastStartedAt && (
                <span>· uptime {formatUptime((now - new Date(srv.lastStartedAt).getTime()) / 1000)}</span>
              )}
              {srv.restartCount > 0 && <span>· {srv.restartCount} restarts</span>}
              {srv.lastDeployedAt && <span>· deployed {timeAgo(srv.lastDeployedAt)}</span>}
            </div>
            {srv.description && (
              <p className="text-sm text-[color:var(--muted)] mt-2">{srv.description}</p>
            )}
            <div className="text-xs mt-2 flex items-center gap-2 flex-wrap">
              <span className="text-[color:var(--muted)]">Public URL / webhook base:</span>
              <a
                href={`/apps/${srv.id}/`}
                target="_blank"
                rel="noopener noreferrer"
                className="font-mono text-indigo-300 hover:underline break-all"
                dir="ltr"
              >
                {typeof window !== "undefined" ? window.location.origin : ""}/apps/{srv.id}/
              </a>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            {canStart && (
              <Button
                size="sm"
                loading={acting === "start"}
                disabled={busy || !!acting}
                onClick={() => action("start")}
              >
                <Play size={14} /> Start
              </Button>
            )}
            {canStop && (
              <Button
                size="sm"
                variant="secondary"
                loading={acting === "stop"}
                disabled={busy || !!acting}
                onClick={() => action("stop")}
              >
                <Square size={14} /> Stop
              </Button>
            )}
            <Button
              size="sm"
              variant="secondary"
              loading={acting === "restart"}
              disabled={busy || !!acting}
              onClick={() => action("restart")}
            >
              <RotateCw size={14} /> Restart
            </Button>
            <Button
              size="sm"
              variant="secondary"
              loading={acting === "redeploy"}
              disabled={busy || !!acting}
              onClick={() => action("redeploy")}
            >
              <Rocket size={14} /> Redeploy
            </Button>
            {(canStop || srv.status === "CRASHED" || busy) && (
              <Button
                size="sm"
                variant="danger"
                loading={acting === "kill"}
                disabled={!!acting}
                onClick={() => confirm("Force kill the process (SIGKILL)?") && action("kill")}
              >
                <Zap size={14} /> Kill
              </Button>
            )}
            <Button size="sm" variant="danger" onClick={deleteServer} aria-label="Delete project">
              <Trash2 size={14} />
            </Button>
          </div>
        </div>
      </Card>

      {/* Tabs */}
      <div className="flex gap-1 overflow-x-auto scrollbar border-b border-[color:var(--border)]">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm whitespace-nowrap border-b-2 transition ${
              tab === t.key
                ? "border-indigo-500 text-indigo-300"
                : "border-transparent text-[color:var(--muted)] hover:text-[color:var(--fg)]"
            }`}
          >
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      <div>
        {tab === "console" && <ConsoleTab serverId={id} />}
        {tab === "files" && <FilesTab serverId={id} />}
        {tab === "metrics" && <MetricsTab serverId={id} />}
        {tab === "env" && <EnvTab serverId={id} />}
        {tab === "domains" && <DomainsTab serverId={id} />}
        {tab === "backups" && <BackupsTab serverId={id} />}
        {tab === "settings" && (
          <SettingsTab
            serverId={id}
            initial={{
              name: srv.name,
              description: srv.description,
              startCommand: srv.startCommand,
              installCommand: srv.installCommand,
              entryPoint: srv.entryPoint,
              autoRestart: srv.autoRestart,
            }}
            onSaved={load}
          />
        )}
      </div>
      {toast.element}
    </div>
  );
}
