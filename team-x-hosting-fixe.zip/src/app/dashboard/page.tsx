"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Server as ServerIcon,
  Activity,
  HardDrive,
  Cpu,
  AlertCircle,
  Plus,
} from "lucide-react";
import { Card, EmptyState, Skeleton, StatusBadge } from "@/components/ui";
import { formatBytes, timeAgo } from "@/lib/utils";

type Overview = {
  user: { id: string; name: string; email: string; status: string; expiresAt: string | null };
  plan: { id: number; name: string; storageMb: number; ramMb: number; cpuMillis: number; maxServers: number } | null;
  servers: {
    total: number; running: number; stopped: number; error: number;
    items: Array<{ id: string; name: string; status: string; runtime: string; runtimeVersion: string; updatedAt: string }>;
  };
  resources: { storageUsedMb: number; storageLimitMb: number; ramLimitMb: number; cpuMillisLimit: number };
  activity: Array<{ id: number; action: string; detail: string | null; createdAt: string }>;
};

export default function DashboardOverview() {
  const [data, setData] = useState<Overview | null>(null);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => {
    fetch("/api/dashboard/overview")
      .then((r) => r.json())
      .then((d) => (d.error ? setErr(d.error) : setData(d)))
      .catch((e) => setErr(String(e)));
  }, []);

  if (err)
    return (
      <Card>
        <div className="text-red-400 flex items-center gap-2">
          <AlertCircle size={16} /> {err}
        </div>
      </Card>
    );

  if (!data) {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
        <Skeleton className="h-64" />
      </div>
    );
  }

  const storagePct = Math.min(
    100,
    Math.round((data.resources.storageUsedMb / data.resources.storageLimitMb) * 100)
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Overview</h1>
        <p className="text-sm text-[color:var(--muted)] mt-1">
          Welcome back, {data.user.name}.
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Stat
          icon={<ServerIcon size={16} />}
          label="Total projects"
          value={data.servers.total}
          hint={`${data.servers.running} running`}
          variant="primary"
        />
        <Stat
          icon={<Activity size={16} />}
          label="Running"
          value={data.servers.running}
          hint={`${data.servers.stopped} stopped`}
          variant="success"
        />
        <Stat
          icon={<HardDrive size={16} />}
          label="Storage"
          value={`${data.resources.storageUsedMb}MB`}
          hint={`of ${data.resources.storageLimitMb}MB (${storagePct}%)`}
          variant="info"
        />
        <Stat
          icon={<Cpu size={16} />}
          label="Plan"
          value={data.plan?.name ?? "Free"}
          hint={`${data.plan?.maxServers ?? 1} projects max`}
          variant="muted"
        />
      </div>

      {/* Storage bar */}
      <Card>
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-semibold text-sm">Storage usage</h3>
          <span className="text-xs text-[color:var(--muted)]">
            {formatBytes(data.resources.storageUsedMb * 1024 * 1024)} /{" "}
            {formatBytes(data.resources.storageLimitMb * 1024 * 1024)}
          </span>
        </div>
        <div className="h-3 bg-[color:var(--card-2)] rounded-full overflow-hidden border border-[color:var(--border)]">
          <div
            className="h-full bg-gradient-to-r from-indigo-500 to-violet-500"
            style={{ width: `${storagePct}%` }}
          />
        </div>
      </Card>

      {/* Projects */}
      <Card padding="p-0">
        <div className="flex items-center justify-between px-5 py-4 border-b border-[color:var(--border)]">
          <h3 className="font-semibold">Recent projects</h3>
          <Link href="/dashboard/servers" className="text-sm text-indigo-400 hover:underline">
            View all →
          </Link>
        </div>
        {data.servers.items.length === 0 ? (
          <EmptyState
            icon={<ServerIcon size={22} />}
            title="No projects yet"
            description="Create your first project to deploy code in seconds."
            action={
              <Link href="/dashboard/servers/new" className="btn btn-primary">
                <Plus size={14} /> Create project
              </Link>
            }
          />
        ) : (
          <div className="divide-y divide-[color:var(--border)]">
            {data.servers.items.map((s) => (
              <Link
                key={s.id}
                href={`/dashboard/servers/${s.id}`}
                className="flex items-center justify-between px-5 py-3 hover:bg-white/5 transition"
              >
                <div className="min-w-0">
                  <div className="font-medium truncate">{s.name}</div>
                  <div className="text-xs text-[color:var(--muted)] mt-0.5">
                    {s.runtime} {s.runtimeVersion} · updated {timeAgo(s.updatedAt)}
                  </div>
                </div>
                <StatusBadge status={s.status} />
              </Link>
            ))}
          </div>
        )}
      </Card>

      {/* Activity */}
      <Card padding="p-0">
        <div className="px-5 py-4 border-b border-[color:var(--border)]">
          <h3 className="font-semibold">Recent activity</h3>
        </div>
        {data.activity.length === 0 ? (
          <EmptyState title="No activity yet" />
        ) : (
          <ul className="divide-y divide-[color:var(--border)]">
            {data.activity.map((a) => (
              <li key={a.id} className="px-5 py-3 text-sm flex justify-between gap-4">
                <span>
                  <span className="font-medium">{a.action.replace(/_/g, " ")}</span>
                  {a.detail && (
                    <span className="text-[color:var(--muted)]"> — {a.detail}</span>
                  )}
                </span>
                <span className="text-xs text-[color:var(--muted)] shrink-0">
                  {timeAgo(a.createdAt)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

function Stat({
  icon,
  label,
  value,
  hint,
  variant,
}: {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  hint?: string;
  variant: "primary" | "success" | "info" | "muted";
}) {
  const bg =
    variant === "primary"
      ? "bg-indigo-500/10 text-indigo-300 border-indigo-500/30"
      : variant === "success"
      ? "bg-emerald-500/10 text-emerald-300 border-emerald-500/30"
      : variant === "info"
      ? "bg-blue-500/10 text-blue-300 border-blue-500/30"
      : "bg-white/5 text-[color:var(--muted)] border-[color:var(--border)]";
  return (
    <Card>
      <div className="flex items-start justify-between">
        <div>
          <div className="text-xs text-[color:var(--muted)]">{label}</div>
          <div className="text-2xl font-bold mt-1">{value}</div>
          {hint && (
            <div className="text-xs text-[color:var(--muted)] mt-1">{hint}</div>
          )}
        </div>
        <div className={`w-8 h-8 rounded-lg border flex items-center justify-center ${bg}`}>
          {icon}
        </div>
      </div>
    </Card>
  );
}
