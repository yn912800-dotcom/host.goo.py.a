import Link from "next/link";
import { db } from "@/db";
import { plans, runtimes, settings } from "@/db/schema";
import { ensureBootstrap } from "@/lib/bootstrap";
import { asc, eq } from "drizzle-orm";
import {
  Rocket,
  Code2,
  Shield,
  Zap,
  Server,
  Terminal,
  GitBranch,
  CheckCircle2,
  Database,
  Globe,
  LineChart,
  FolderUp,
} from "lucide-react";
import { Providers } from "@/components/providers";
import LandingHeader from "./_landing/LandingHeader";

export const dynamic = "force-dynamic";

export default async function Home() {
  await ensureBootstrap();
  const [plansRows, runtimeRows, settingRow] = await Promise.all([
    db.select().from(plans).where(eq(plans.isActive, true)).orderBy(asc(plans.sortOrder)),
    db.select().from(runtimes).where(eq(runtimes.isEnabled, true)).orderBy(asc(runtimes.type)),
    db.select().from(settings).where(eq(settings.key, "platform")).limit(1),
  ]);
  const brand =
    ((settingRow[0]?.value as Record<string, unknown>)?.platformName as string) ??
    "•-تــيــ۾ إڪـXـس-•";

  const runtimeFamilies = Array.from(
    new Set(runtimeRows.map((r) => r.type))
  );

  return (
    <Providers>
      <LandingHeader brand={brand} />
      <main>
        {/* Hero */}
        <section className="relative overflow-hidden">
          <div className="max-w-6xl mx-auto px-5 pt-20 pb-24 text-center">
            <div className="inline-flex items-center gap-2 text-xs uppercase tracking-wider text-[color:var(--muted)] mb-6 border border-[color:var(--border)] rounded-full px-3 py-1">
              <Rocket size={14} /> Modern Hosting Platform
            </div>
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold leading-tight max-w-3xl mx-auto">
              Deploy any project in{" "}
              <span className="gradient-text">seconds.</span>
            </h1>
            <p className="text-lg text-[color:var(--muted)] mt-5 max-w-2xl mx-auto">
              A professional PaaS for your side-projects and production apps.
              Upload code, we detect your runtime, install dependencies, and keep
              it running — all from your browser.
            </p>
            <div className="flex flex-wrap gap-3 justify-center mt-8">
              <Link href="/register" className="btn btn-primary">
                Start free
              </Link>
              <Link href="#plans" className="btn btn-secondary">
                See plans
              </Link>
            </div>
            {/* Visual mock terminal */}
            <div className="mt-14 max-w-3xl mx-auto console p-5 text-left shadow-2xl">
              <div className="flex gap-1.5 mb-3">
                <span className="w-3 h-3 rounded-full bg-red-400/80" />
                <span className="w-3 h-3 rounded-full bg-yellow-400/80" />
                <span className="w-3 h-3 rounded-full bg-green-400/80" />
              </div>
              <pre className="text-xs sm:text-sm overflow-x-auto">
                <span className="text-slate-500">$</span>{" "}
                <span className="text-indigo-300">arenahost</span> deploy ./my-bot
                {"\n"}
                <span className="text-slate-500">→</span> Detected runtime:{" "}
                <span className="text-emerald-300">python 3.11</span>
                {"\n"}
                <span className="text-slate-500">→</span> Installing{" "}
                <span className="text-indigo-300">requirements.txt</span>...
                {"\n"}
                <span className="text-slate-500">→</span> Starting container...
                {"\n"}
                <span className="text-slate-500">→</span>{" "}
                <span className="text-emerald-300">
                  ✓ Live at my-bot.arenahost.app
                </span>
              </pre>
            </div>
          </div>
        </section>

        {/* Stats strip */}
        <section className="max-w-6xl mx-auto px-5 -mt-6 mb-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: "Supported runtimes", value: `${runtimeFamilies.length}+` },
              { label: "Max deploy time", value: "~30s" },
              { label: "Projects on free", value: "1" },
              { label: "Uptime target", value: "99.9%" },
            ].map((s) => (
              <div key={s.label} className="card p-4 text-center">
                <div className="text-2xl font-bold gradient-text">{s.value}</div>
                <div className="text-xs text-[color:var(--muted)] mt-1">{s.label}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Features */}
        <section id="features" className="max-w-6xl mx-auto px-5 py-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold">
              Everything you need to ship.
            </h2>
            <p className="text-[color:var(--muted)] mt-3">
              From upload to live URL — all in your browser.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              {
                icon: Rocket,
                title: "Telegram & WhatsApp bots",
                desc: "Run bots 24/7 in Python, Node.js or PHP. One-click templates, live console, WhatsApp QR linking, auto-restart on crash.",
              },
              {
                icon: FolderUp,
                title: "Upload & auto-detect",
                desc: "Drop a ZIP or individual files. We detect your runtime and entry point automatically.",
              },
              {
                icon: Terminal,
                title: "Live console & logs",
                desc: "Watch your build and runtime output in real-time, right in the dashboard.",
              },
              {
                icon: Code2,
                title: "Browser code editor",
                desc: "Edit files with syntax highlighting powered by Monaco. No local setup required.",
              },
              {
                icon: Server,
                title: "Managed containers",
                desc: "Each project runs isolated with CPU, RAM and storage limits based on your plan.",
              },
              {
                icon: GitBranch,
                title: "One-click redeploy",
                desc: "Push changes, click redeploy. We re-install, rebuild and restart with zero downtime.",
              },
              {
                icon: LineChart,
                title: "Metrics & monitoring",
                desc: "CPU, RAM, storage and uptime charts for every project. Alerts on crashes.",
              },
              {
                icon: Database,
                title: "Backups & restore",
                desc: "Snapshot your project files any time. Restore in a single click.",
              },
              {
                icon: Globe,
                title: "Custom domains + SSL",
                desc: "Bring your own domain. SSL via Let's Encrypt is set up automatically.",
              },
              {
                icon: Shield,
                title: "Secure by default",
                desc: "Per-user isolation, bcrypt passwords, httpOnly sessions and strict path validation.",
              },
            ].map((f) => (
              <div key={f.title} className="card p-5">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 mb-3">
                  <f.icon size={18} />
                </div>
                <h3 className="font-semibold">{f.title}</h3>
                <p className="text-sm text-[color:var(--muted)] mt-1.5 leading-relaxed">
                  {f.desc}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Runtimes */}
        <section id="runtimes" className="max-w-6xl mx-auto px-5 py-16">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold">Supported runtimes</h2>
            <p className="text-[color:var(--muted)] mt-3">
              Add or disable runtimes anytime from the admin panel.
            </p>
          </div>
          <div className="flex flex-wrap gap-3 justify-center">
            {runtimeRows.map((r) => (
              <div
                key={r.id}
                className="card px-4 py-3 flex items-center gap-2 min-w-[150px]"
              >
                <Zap size={16} className="text-indigo-400" />
                <span className="font-medium">{r.displayName}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Plans */}
        <section id="plans" className="max-w-6xl mx-auto px-5 py-16">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold">Simple pricing</h2>
            <p className="text-[color:var(--muted)] mt-3">
              Start free. Upgrade when you need more.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {plansRows.map((p, i) => (
              <div
                key={p.id}
                className={`card p-6 flex flex-col ${
                  i === 2 ? "ring-1 ring-indigo-500/50" : ""
                }`}
              >
                {i === 2 && (
                  <div className="text-xs uppercase tracking-wide text-indigo-300 mb-2">
                    Most popular
                  </div>
                )}
                <h3 className="text-lg font-semibold">{p.name}</h3>
                <div className="mt-2 flex items-baseline gap-1">
                  <span className="text-3xl font-bold">
                    ${(p.priceCents / 100).toFixed(0)}
                  </span>
                  <span className="text-sm text-[color:var(--muted)]">/mo</span>
                </div>
                <p className="text-sm text-[color:var(--muted)] mt-2 h-10">
                  {p.description}
                </p>
                <ul className="mt-4 space-y-2 text-sm flex-1">
                  {p.features.map((f: string) => (
                    <li key={f} className="flex items-start gap-2">
                      <CheckCircle2
                        size={16}
                        className="text-emerald-400 mt-0.5 flex-shrink-0"
                      />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                <Link
                  href="/register"
                  className={`btn mt-6 ${
                    i === 2 ? "btn-primary" : "btn-secondary"
                  }`}
                >
                  {p.priceCents === 0 ? "Get started" : "Choose plan"}
                </Link>
              </div>
            ))}
          </div>
        </section>

        {/* How it works */}
        <section className="max-w-6xl mx-auto px-5 py-16">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold">How it works</h2>
          </div>
          <div className="grid md:grid-cols-4 gap-4">
            {[
              { step: "1", title: "Create account", desc: "Sign up free. Takes 10 seconds." },
              { step: "2", title: "Upload project", desc: "Drop a ZIP or pick files from your computer." },
              { step: "3", title: "We detect & deploy", desc: "Runtime, entry point, dependencies — all automatic." },
              { step: "4", title: "You're live", desc: "Your project runs in an isolated container with a public URL." },
            ].map((s) => (
              <div key={s.step} className="card p-5">
                <div className="text-sm font-bold w-8 h-8 rounded-full bg-indigo-500/20 text-indigo-300 flex items-center justify-center">
                  {s.step}
                </div>
                <h3 className="font-semibold mt-3">{s.title}</h3>
                <p className="text-sm text-[color:var(--muted)] mt-1">{s.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* FAQ */}
        <section id="faq" className="max-w-3xl mx-auto px-5 py-16">
          <h2 className="text-3xl font-bold text-center mb-10">
            Frequently asked questions
          </h2>
          <div className="space-y-3">
            {[
              {
                q: "What runtimes do you support?",
                a: "Node.js, Python, PHP and static HTML are enabled by default. Go, Java, Ruby and Rust runtimes are available and can be toggled from the admin panel.",
              },
              {
                q: "How are projects isolated?",
                a: "Each project is designed to run inside its own container with CPU, RAM and storage limits enforced at the host level. Admins can tune limits per plan.",
              },
              {
                q: "Can I bring my own domain?",
                a: "Yes. Add a custom domain from the project settings. SSL via Let's Encrypt is provisioned automatically on paid plans.",
              },
              {
                q: "Is my code safe?",
                a: "Passwords are hashed with bcrypt. Sessions are httpOnly. User files are strictly scoped — one user cannot read another user's project files even if they know the ID.",
              },
              {
                q: "Can I export my project?",
                a: "Any time — create a backup from your project's Backups tab and restore it to any other project.",
              },
            ].map((f) => (
              <details key={f.q} className="card p-5">
                <summary className="cursor-pointer font-medium">{f.q}</summary>
                <p className="text-sm text-[color:var(--muted)] mt-2 leading-relaxed">
                  {f.a}
                </p>
              </details>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section className="max-w-5xl mx-auto px-5 py-16">
          <div className="card p-10 text-center">
            <h2 className="text-3xl font-bold">Ready to deploy?</h2>
            <p className="text-[color:var(--muted)] mt-2">
              Create your account and have your first project running in minutes.
            </p>
            <Link href="/register" className="btn btn-primary mt-6 inline-flex">
              Get started free
            </Link>
          </div>
        </section>

        <footer className="border-t border-[color:var(--border)] py-10 mt-10">
          <div className="max-w-6xl mx-auto px-5 flex flex-col sm:flex-row justify-between items-center gap-4 text-sm text-[color:var(--muted)]">
            <div>
              © {new Date().getFullYear()} {brand}. All rights reserved.
            </div>
            <div className="flex gap-5">
              <Link href="/login">Log in</Link>
              <Link href="/register">Sign up</Link>
              <a href="#plans">Pricing</a>
              <a href="#faq">FAQ</a>
            </div>
          </div>
        </footer>
      </main>
    </Providers>
  );
}
